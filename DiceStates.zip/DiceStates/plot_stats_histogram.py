import matplotlib.pyplot as plt
import numpy as np 
import pandas as pd 

dice_rolls = pd.read_csv('dice_rolls2.csv', header=None)

print(dice_rolls.size)
plt.hist(dice_rolls)
plt.show()