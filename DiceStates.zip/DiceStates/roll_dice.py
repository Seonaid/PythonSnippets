import random
import csv

def roll_dice(num_dice, sides, discards=0):
    random.seed()
    all_dice=[random.randint(1,sides) for dice in range(num_dice)]
    for i in range(discards):
        all_dice.remove(min(all_dice))
    
    return sum(all_dice)

all_rolls = [roll_dice(3,6) for dice in range(20000)]
with open('dice_rolls2.csv', 'w') as current_rolls:
    wr = csv.writer(current_rolls)
    wr.writerow(all_rolls)